extends CharacterBody3D

const WALK_SPEED := 3.2
const RUN_SPEED := 5.2
const MOUSE_SENSITIVITY := 0.0022
const GRAVITY := 18.0

var camera: Camera3D
var flashlight: SpotLight3D
var pitch := 0.0
var hud_label: Label

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_build_player_rig()
	_build_hud()

func _build_player_rig() -> void:
	var capsule := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.75
	capsule.shape = shape
	capsule.position.y = 0.88
	add_child(capsule)

	camera = Camera3D.new()
	camera.position = Vector3(0, 1.55, 0)
	camera.fov = 78
	add_child(camera)

	flashlight = SpotLight3D.new()
	flashlight.position = Vector3(0.15, -0.12, -0.18)
	flashlight.rotation_degrees.x = -4
	flashlight.light_color = Color(0.78, 0.86, 1.0)
	flashlight.light_energy = 2.1
	flashlight.spot_range = 17.0
	flashlight.spot_angle = 34.0
	flashlight.shadow_enabled = false # keep mobile-friendly
	camera.add_child(flashlight)

func _build_hud() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)
	var center := Label.new()
	center.text = "+"
	center.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	center.position = Vector2(get_viewport().get_visible_rect().size.x / 2 - 8, get_viewport().get_visible_rect().size.y / 2 - 14)
	center.add_theme_font_size_override("font_size", 22)
	center.add_theme_color_override("font_color", Color(0.8, 0.85, 0.9, 0.65))
	canvas.add_child(center)

	hud_label = Label.new()
	hud_label.text = "MALAM TERAKHIR  |  WASD: Gerak  SHIFT: Lari  F: Senter  ESC: Lepas mouse"
	hud_label.position = Vector2(18, 18)
	hud_label.add_theme_font_size_override("font_size", 14)
	hud_label.add_theme_color_override("font_color", Color(0.78, 0.82, 0.88))
	canvas.add_child(hud_label)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * MOUSE_SENSITIVITY)
		pitch = clamp(pitch - event.relative.y * MOUSE_SENSITIVITY, -1.45, 1.45)
		camera.rotation.x = pitch
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseButton and event.pressed and Input.mouse_mode == Input.MOUSE_MODE_VISIBLE:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if event is InputEventKey and event.pressed and event.keycode == KEY_F:
		flashlight.visible = not flashlight.visible

func _physics_process(delta: float) -> void:
	var input_dir := Vector2.ZERO
	input_dir.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
	input_dir.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
	# Add WASD directly for convenience
	if Input.is_key_pressed(KEY_A): input_dir.x -= 1.0
	if Input.is_key_pressed(KEY_D): input_dir.x += 1.0
	if Input.is_key_pressed(KEY_W): input_dir.y -= 1.0
	if Input.is_key_pressed(KEY_S): input_dir.y += 1.0
	input_dir = input_dir.normalized()
	var speed := RUN_SPEED if Input.is_key_pressed(KEY_SHIFT) else WALK_SPEED
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0
	move_and_slide()
