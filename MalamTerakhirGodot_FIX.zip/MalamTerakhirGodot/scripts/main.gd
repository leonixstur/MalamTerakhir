extends Node3D

# Small procedural 3D horror scene for Godot 4.x. No external assets required.

func _ready() -> void:
	_build_world()
	_build_player()
	_build_village()

func _build_world() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.012, 0.018, 0.03)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.16, 0.19, 0.27)
	env.ambient_light_energy = 0.35
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_env.environment = env
	add_child(world_env)

	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-48, -25, 0)
	moon.light_color = Color(0.48, 0.57, 0.8)
	moon.light_energy = 0.22
	moon.shadow_enabled = true
	add_child(moon)

	var floor_body := StaticBody3D.new()
	floor_body.name = "Ground"
	var floor_mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(100, 100)
	floor_mesh.mesh = plane
	var ground_mat := StandardMaterial3D.new()
	ground_mat.albedo_color = Color(0.09, 0.105, 0.09)
	ground_mat.roughness = 1.0
	floor_mesh.material_override = ground_mat
	floor_body.add_child(floor_mesh)
	var floor_collision := CollisionShape3D.new()
	var floor_shape := BoxShape3D.new()
	floor_shape.size = Vector3(100, 0.2, 100)
	floor_collision.shape = floor_shape
	floor_collision.position.y = -0.1
	floor_body.add_child(floor_collision)
	add_child(floor_body)

func _build_player() -> void:
	var player := CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 1, 7)
	player.set_script(load("res://scripts/player.gd"))
	add_child(player)

func _build_village() -> void:
	# Dirt path
	_add_box(Vector3(0, 0.03, -4), Vector3(3.4, 0.06, 42), Color(0.16, 0.14, 0.12), false)
	# Simple low-poly houses along the village road
	_add_house(Vector3(-7, 0, -3), Color(0.25, 0.19, 0.15))
	_add_house(Vector3(7, 0, -10), Color(0.20, 0.22, 0.19))
	_add_house(Vector3(-8, 0, -20), Color(0.24, 0.18, 0.18))
	_add_house(Vector3(8, 0, -27), Color(0.18, 0.19, 0.24))
	# Trees and poles
	for i in range(14):
		var z := -float(i) * 3.8 + 8.0
		_add_tree(Vector3(-13 if i % 2 == 0 else 13, 0, z))
	# A distant ominous silhouette
	_add_box(Vector3(0, 1.3, -32), Vector3(0.65, 2.6, 0.35), Color(0.015, 0.012, 0.02), false)
	_add_box(Vector3(0, 2.65, -32), Vector3(0.9, 0.7, 0.45), Color(0.01, 0.008, 0.015), false)

func _add_house(pos: Vector3, wall_color: Color) -> void:
	var house := StaticBody3D.new()
	house.position = pos
	add_child(house)
	_add_box_local(house, Vector3(0, 1.25, 0), Vector3(4.2, 2.5, 3.6), wall_color, true)
	# roof halves form a simple peaked roof
	_add_box_local(house, Vector3(0, 2.85, -0.95), Vector3(4.8, 0.18, 2.2), Color(0.09, 0.055, 0.045), false, Vector3(-22, 0, 0))
	_add_box_local(house, Vector3(0, 2.85, 0.95), Vector3(4.8, 0.18, 2.2), Color(0.09, 0.055, 0.045), false, Vector3(22, 0, 0))
	# door and dim window glow
	_add_box_local(house, Vector3(0, 0.9, -1.83), Vector3(0.85, 1.8, 0.08), Color(0.055, 0.035, 0.025), false)
	_add_box_local(house, Vector3(1.25, 1.45, -1.86), Vector3(0.65, 0.55, 0.08), Color(0.28, 0.17, 0.07), false)
	var glow := OmniLight3D.new()
	glow.position = Vector3(1.25, 1.55, -2.2)
	glow.light_color = Color(1.0, 0.42, 0.12)
	glow.light_energy = 0.35
	glow.omni_range = 4.0
	house.add_child(glow)

func _add_tree(pos: Vector3) -> void:
	var tree := Node3D.new()
	tree.position = pos
	add_child(tree)
	var trunk := MeshInstance3D.new()
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.18
	trunk_mesh.bottom_radius = 0.28
	trunk_mesh.height = 2.7
	trunk.mesh = trunk_mesh
	var bark := StandardMaterial3D.new()
	bark.albedo_color = Color(0.12, 0.075, 0.05)
	trunk.material_override = bark
	trunk.position.y = 1.35
	tree.add_child(trunk)
	var crown := MeshInstance3D.new()
	var crown_mesh := SphereMesh.new()
	crown_mesh.radius = 1.25
	crown_mesh.height = 2.2
	crown.mesh = crown_mesh
	var leaves := StandardMaterial3D.new()
	leaves.albedo_color = Color(0.025, 0.07, 0.045)
	leaves.roughness = 1.0
	crown.material_override = leaves
	crown.position.y = 3.0
	tree.add_child(crown)

func _add_box(pos: Vector3, size: Vector3, color: Color, with_collision: bool) -> void:
	var body: Node3D
	if with_collision:
		body = StaticBody3D.new()
	else:
		body = Node3D.new()
	body.position = pos
	add_child(body)
	_add_box_local(body, Vector3.ZERO, size, color, with_collision)

func _add_box_local(parent: Node3D, pos: Vector3, size: Vector3, color: Color, with_collision: bool, rot_deg: Vector3 = Vector3.ZERO) -> void:
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.95
	mesh_instance.material_override = mat
	mesh_instance.position = pos
	mesh_instance.rotation_degrees = rot_deg
	parent.add_child(mesh_instance)
	if with_collision:
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		collision.shape = shape
		collision.position = pos
		collision.rotation_degrees = rot_deg
		parent.add_child(collision)
